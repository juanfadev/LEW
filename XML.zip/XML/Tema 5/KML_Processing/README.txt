Para generar un KML proceso el XML de prerromanico usando el script de python que hay en esta carpeta.

Genero un arbol nuevo XML con la sintaxis KML, con las localizaciones y la descripción y titulo.