﻿Este ejercicio incluye los dos ejercicios de este tema de entrada de XML y salida de XML.

Primero obtiene el archivo feed.xml a partir de una fuente rss de la web as.com

A continuación procesa ese archivo (entrada XML), y genera un PDF con un resumen de las noticias incluidas en el feed.xml.
Paralelamente genera un arbol XML con la información estructurada de una mejor forma que en el feed.xml y lo exporta con el nombre de segunda_division.xml (salida XML).


En la carpeta dejo dos ejemplos de PDF generado. Cada PDF que genera se genera con una fecha y hora distintas por si se quisieran almacenar. 
Los XML se generan con el mismo nombre y sobreescriben al anterior, ya que en un principio estarían hechos para servir en una aplicación que consumiera dicho XML en tiempo real.