Para este trabajo he incluido dos tipos de div. Uno para agrupar los botones inferiores con efecto "glow", 
y otro con una "galería" para encapsular las figuras o imágenes que están en una sección, y que así no ocupen en conjunto más de lo que deberían.


También he incluido unos SVG en el footer. Los SVG de las RRSS se ven pequeños, sin embargo no encontré ningún SVG más optimizado con el logo de Uniovi (está minimizado)

Todos los archivos han sido validados y todas las páginas superan las WCAG 2.0 Level AA. 
Los CSS tienen algún warning relacionado con redefiniciones, principalmente por intentar hacer responsive el contenido.